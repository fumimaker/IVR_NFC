**GitHub Issues are for bugs and feature requests.**

Please do not post usage questions here. For general support from the community, see StackOverflow: http://stackoverflow.com/questions/tagged/gspread

Issues with usage questions will be closed.

For bugs please provide the following information.

### Environment info

Operating System:
Python version:
gspread version:

### Steps to reproduce
1.
2.
3.

### Stack trace or other output that would be helpful
